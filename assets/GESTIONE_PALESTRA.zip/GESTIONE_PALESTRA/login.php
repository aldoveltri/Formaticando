<?php
session_start();
$conn = new mysqli("localhost", "root", "", "palestra");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST["username"];
    $pass = hash("sha256", $_POST["password"]);

    $stmt = $conn->prepare("SELECT id, ruolo FROM utenti WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $user, $pass);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $ruolo);
        $stmt->fetch();
        $_SESSION["user_id"] = $id;
        $_SESSION["ruolo"] = $ruolo;

        $conn->query("INSERT INTO log_attivita (id_utente, azione) VALUES ($id, 'Login')");

        header("Location: pagamenti.php");
    } else {
        echo "Credenziali errate";
    }
}
?>

<form method="post">
    Username: <input type="text" name="username" required><br>
    Password: <input type="password" name="password" required><br>
    <input type="submit" value="Accedi">
</form>
<a href="register.php">Registrati</a>