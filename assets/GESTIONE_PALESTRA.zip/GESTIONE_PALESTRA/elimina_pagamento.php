<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["ruolo"] != "admin") {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "palestra");
$id = $_GET["id"];

$conn->query("DELETE FROM pagamenti WHERE id = $id");
$conn->query("INSERT INTO log_attivita (id_utente, azione) VALUES ({$_SESSION["user_id"]}, 'Eliminato pagamento ID $id')");

header("Location: pagamenti.php");