<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["ruolo"] != "admin") {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "palestra");
$id = $_GET["id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = $_POST["data"];
    $importo = $_POST["importo"];
    $note = $_POST["note"];

    $stmt = $conn->prepare("UPDATE pagamenti SET data_pagamento = ?, importo = ?, note = ? WHERE id = ?");
    $stmt->bind_param("sdsi", $data, $importo, $note, $id);
    $stmt->execute();

    $conn->query("INSERT INTO log_attivita (id_utente, azione) VALUES ({$_SESSION["user_id"]}, 'Modificato pagamento ID $id')");

    header("Location: pagamenti.php");
    exit();
}

$result = $conn->query("SELECT * FROM pagamenti WHERE id = $id");
$row = $result->fetch_assoc();
?>

<form method="post">
    Data: <input type="date" name="data" value="<?= $row['data_pagamento'] ?>" required><br>
    Importo: <input type="number" step="0.01" name="importo" value="<?= $row['importo'] ?>" required><br>
    Note: <input type="text" name="note" value="<?= $row['note'] ?>"><br>
    <input type="submit" value="Modifica">
</form>