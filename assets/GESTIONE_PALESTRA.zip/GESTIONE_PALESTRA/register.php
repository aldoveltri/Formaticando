<?php
$conn = new mysqli("localhost", "root", "", "palestra");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST["username"];
    $pass = hash("sha256", $_POST["password"]);

    $stmt = $conn->prepare("INSERT INTO utenti (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $user, $pass);
    $stmt->execute();

    echo "Registrazione avvenuta. <a href='login.php'>Accedi</a>";
    exit();
}
?>

<form method="post">
    Username: <input type="text" name="username" required><br>
    Password: <input type="password" name="password" required><br>
    <input type="submit" value="Registrati">
</form>