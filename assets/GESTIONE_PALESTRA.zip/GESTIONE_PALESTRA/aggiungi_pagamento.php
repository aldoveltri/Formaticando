<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["ruolo"] != "admin") {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "palestra");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_utente = $_POST["id_utente"];
    $data = $_POST["data"];
    $importo = $_POST["importo"];
    $note = $_POST["note"];

    $stmt = $conn->prepare("INSERT INTO pagamenti (id_utente, data_pagamento, importo, note) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isds", $id_utente, $data, $importo, $note);
    $stmt->execute();

    $admin_id = $_SESSION["user_id"];
    $conn->query("INSERT INTO log_attivita (id_utente, azione) VALUES ($admin_id, 'Aggiunto pagamento per utente ID $id_utente')");

    echo "Pagamento aggiunto.<br><a href='pagamenti.php'>Torna indietro</a>";
    exit();
}

$utenti = $conn->query("SELECT id, username FROM utenti");
?>

<form method="post">
    Utente:
    <select name="id_utente">
        <?php while ($u = $utenti->fetch_assoc()): ?>
            <option value="<?= $u['id'] ?>"><?= $u['username'] ?></option>
        <?php endwhile; ?>
    </select><br>
    Data: <input type="date" name="data" required><br>
    Importo: <input type="number" step="0.01" name="importo" required><br>
    Note: <input type="text" name="note"><br>
    <input type="submit" value="Aggiungi">
</form>