<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["ruolo"] != "admin") {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "palestra");
$log = $conn->query("SELECT log_attivita.*, utenti.username FROM log_attivita JOIN utenti ON log_attivita.id_utente = utenti.id ORDER BY data_ora DESC");
?>

<h2>Log Attività</h2>
<table border="1">
    <tr><th>Utente</th><th>Azione</th><th>Data/Ora</th></tr>
    <?php while ($r = $log->fetch_assoc()): ?>
        <tr>
            <td><?= $r['username'] ?></td>
            <td><?= $r['azione'] ?></td>
            <td><?= $r['data_ora'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<a href="pagamenti.php">Torna</a>