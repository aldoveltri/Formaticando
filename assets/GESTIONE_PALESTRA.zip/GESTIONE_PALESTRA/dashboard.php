<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["ruolo"] != "admin") {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "palestra");
$totale = $conn->query("SELECT SUM(importo) AS totale FROM pagamenti")->fetch_assoc()['totale'];
$numero_utenti = $conn->query("SELECT COUNT(*) AS utenti FROM utenti")->fetch_assoc()['utenti'];
$numero_pagamenti = $conn->query("SELECT COUNT(*) AS pagamenti FROM pagamenti")->fetch_assoc()['pagamenti'];
?>

<h2>Dashboard</h2>
<p>Totale incassato: € <?= number_format($totale, 2) ?></p>
<p>Numero utenti: <?= $numero_utenti ?></p>
<p>Numero pagamenti: <?= $numero_pagamenti ?></p>

<a href="pagamenti.php">Torna</a>