<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "palestra");

$user_id = $_SESSION["user_id"];
$ruolo = $_SESSION["ruolo"];

echo "<h2>Benvenuto, ruolo: $ruolo</h2>";

if ($ruolo == "admin") {
    $query = "SELECT pagamenti.*, utenti.username 
              FROM pagamenti 
              JOIN utenti ON pagamenti.id_utente = utenti.id";
    $result = $conn->query($query);
} else {
    $stmt = $conn->prepare("SELECT data_pagamento, importo, note FROM pagamenti WHERE id_utente = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
}
?>

<h3>Storico Pagamenti</h3>
<table border="1">
    <tr>
        <?php if ($ruolo == "admin") echo "<th>Utente</th>"; ?>
        <th>Data</th><th>Importo</th><th>Note</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <?php if ($ruolo == "admin") echo "<td>{$row['username']}</td>"; ?>
            <td><?= $row['data_pagamento'] ?></td>
            <td>€ <?= $row['importo'] ?></td>
            <td><?= $row['note'] ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<?php if ($ruolo == "admin"): ?>
    <a href="aggiungi_pagamento.php">Aggiungi Pagamento</a><br>
<?php endif; ?>

<a href="log.php">Visualizza Log</a> | 
<a href="logout.php">Logout</a>
